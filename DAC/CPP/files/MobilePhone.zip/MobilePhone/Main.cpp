// Main Function of Mobile Phone into a File

#include"MobilePhone.h"
#include<iostream>
#include<fstream>
#include<cstring>
using namespace std;

int main()
{

	string filename;
	cout<<"Enter the file name: "<<endl;
	cin>>filename;
	int num;
	cout<<"Enter the no of records to be done: "<<endl;
        cin>>num;
	while(true)
	{
		cout<<"________________Menu______________"<<endl;
		cout<<"1.Write MobilePhone Details into File"<<endl;
		cout<<"2.Read MobilePhone Details from File to console"<<endl;
		cout<<"3.Sort MobilePhone Details By its Price"<<endl;
		cout<<"4.Exit from the program"<<endl;
		cout<<"________________________________________"<<endl;

		int choice;
		cout<<"Enter your choice"<<endl;
		cin>>choice;
		//cout<<"Enter the no of records to be done: "<<endl;
        	//cin>>num;
        	MobilePhone mp[num];
		
		switch(choice)
		{
			case 1:
				{
					
					ofstream fout(filename,ios::out|ios::binary);
					for(int i=0;i<num;i++)
					{
						mp[i].Accept();
						fout.write((char*)&mp[i],sizeof(mp[i]));
					}
					fout.close();
					cout<<"Data stored......"<<endl;
					break;
				}
			case 2:
				{
					
					ifstream fin(filename,ios::in|ios::binary);
					for(int i=0;i<num;i++)
					{
						//mp[i]->Display();
						fin.read((char*)&mp[i],sizeof(mp[i]));
						mp[i].Display();
					}
					fin.close();
					break;
				}
			case 3:
				{
					
					MobilePhone::sortByPrice(mp,num);
					break;
				}
			case 4:
				{
					exit(0);
				}
		}
	}

	return 0;
}
