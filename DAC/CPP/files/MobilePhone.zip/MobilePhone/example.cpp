// Main Function of Mobile Phone into a File

#include"MobilePhone.h"
#include<iostream>
#include<fstream>
#include<cstring>
using namespace std;

int main()
{

	//string filename;
	//cout<<"Enter the file name: "<<endl;
	//cin>>filename;
	int cnt=0;
	//cout<<"Enter the no of records to be done: "<<endl;
        //cin>>num;
	while(true)
	{
		cout<<"________________Menu______________"<<endl;
		cout<<"1.Write MobilePhone Details into File"<<endl;
		cout<<"2.Read MobilePhone Details from File to console"<<endl;
		cout<<"3.Sort MobilePhone Details By its Price"<<endl;
		cout<<"4.Exit from the program"<<endl;
		cout<<"________________________________________"<<endl;

		int choice;
		cout<<"Enter your choice"<<endl;
		cin>>choice;
		//cout<<"Enter the no of records to be done: "<<endl;
        	//cin>>num;
        	MobilePhone mp,int arr[10];
		
		switch(choice)
		{
			case 1:
				{
					
					ofstream fout("mobile.txt",ios::app|ios::binary);
					//for(int i=0;i<num;i++)
					//{
						//mp.Accept();
						char ch;
						//fout.write((char*)&mp,sizeof(MobilePhone));
						do
						{
							mp.Accept();
							fout.write((char*)&mp,sizeof(MobilePhone));
						 	cout<<"Do you want to continue(y or n)"<<endl;
							cin>>ch;
							cin.get();
						}while(ch!='n');

					//}
					fout.close();
					cout<<"Data stored......"<<endl;
					break;
				}
			case 2:
				{
					
					ifstream fin("mobile.txt",ios::binary);
					//for(int i=0;i<num;i++)
					//{
						//mp[i]->Display();
						while(fin.read((char*)&mp,sizeof(mp)))
						{
							mp.Display();
							arr[cnt] = mp;
							cnt++;
						}
				//	}
					fin.close();
					cout<<"Array is:"<<endl;
					for(int i=0;i<cnt-1;i++)
					{
						cout<<arr[i];
					}
					break;
				}
			case 3:
				{
					
					mp.sortByPrice(arr,cnt);
					//cout<<"count"<<cnt<<endl;
					break;
				}
			case 4:
				{
					exit(0);
				}
		}
	}

	return 0;
}
